"""API regression tests for auth, subscription gating, admin analytics, and core page data endpoints."""

import os
import uuid

import pytest
import requests


@pytest.fixture(scope="session")
def base_url():
    raw = os.environ.get("REACT_APP_BACKEND_URL")
    if not raw:
        pytest.skip("REACT_APP_BACKEND_URL is not set")
    return raw.rstrip("/")


@pytest.fixture
def api_client():
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


def _register_owner(api_client, base_url):
    unique = uuid.uuid4().hex[:10]
    payload = {
        "full_name": f"TEST Owner {unique}",
        "email": f"test_owner_{unique}@example.com",
        "password": "Test@12345",
        "business_name": f"TEST Biz {unique}",
        "gstin": "29ABCDE1234F1Z5",
    }
    response = api_client.post(f"{base_url}/api/auth/register-owner", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["email"] == payload["email"]
    assert data["user"]["role"] == "owner"
    assert isinstance(data["token"], str) and data["token"]
    return payload, data


def _auth_headers(token: str):
    return {"Authorization": f"Bearer {token}"}


def test_owner_registration_and_login(api_client, base_url):
    owner_payload, register_data = _register_owner(api_client, base_url)

    login_response = api_client.post(
        f"{base_url}/api/auth/login",
        json={"email": owner_payload["email"], "password": owner_payload["password"]},
    )
    assert login_response.status_code == 200
    login_data = login_response.json()
    assert login_data["user"]["id"] == register_data["user"]["id"]
    assert login_data["user"]["business_id"] == register_data["user"]["business_id"]
    assert login_data["user"]["role"] == "owner"


def test_super_admin_login_and_analytics_visibility(api_client, base_url):
    login_response = api_client.post(
        f"{base_url}/api/auth/login",
        json={"email": "admin@mybillbook.dev", "password": "admin123"},
    )
    assert login_response.status_code == 200
    login_data = login_response.json()
    assert login_data["user"]["role"] == "super_admin"

    analytics_response = api_client.get(
        f"{base_url}/api/admin/analytics?period=month",
        headers=_auth_headers(login_data["token"]),
    )
    assert analytics_response.status_code == 200
    analytics = analytics_response.json()
    assert analytics["period"] == "month"
    assert "total_sales" in analytics
    assert "promo_usage" in analytics


def test_subscription_access_status_and_read_only_lock_before_activation(api_client, base_url):
    _, auth_data = _register_owner(api_client, base_url)
    token = auth_data["token"]

    status_response = api_client.get(
        f"{base_url}/api/subscriptions/access-status",
        headers=_auth_headers(token),
    )
    assert status_response.status_code == 200
    status_data = status_response.json()
    assert status_data["has_active_subscription"] is False

    party_response = api_client.post(
        f"{base_url}/api/parties",
        headers=_auth_headers(token),
        json={
            "name": "TEST Party Locked",
            "phone": "9999999999",
            "gstin": "27ABCDE1234F1Z5",
            "address": "Read-only street",
            "balance_type": "receivable",
            "current_balance": 0,
        },
    )
    assert party_response.status_code == 402
    assert "Active subscription" in party_response.json()["detail"]


def test_mock_payment_activation_enables_create_actions(api_client, base_url):
    _, auth_data = _register_owner(api_client, base_url)
    token = auth_data["token"]

    activate_response = api_client.post(
        f"{base_url}/api/subscriptions/activate",
        headers=_auth_headers(token),
        json={"plan_id": "starter", "billing_cycle": "monthly", "promo_code": None},
    )
    assert activate_response.status_code == 200
    activate_data = activate_response.json()
    assert activate_data["status"] == "active"
    assert activate_data["payment_status"] == "MOCKED_SUCCESS"

    status_response = api_client.get(
        f"{base_url}/api/subscriptions/access-status",
        headers=_auth_headers(token),
    )
    assert status_response.status_code == 200
    assert status_response.json()["has_active_subscription"] is True

    party_payload = {
        "name": "TEST Party Active",
        "phone": "8888888888",
        "gstin": "29ABCDE1234F1Z5",
        "address": "Active street",
        "balance_type": "receivable",
        "current_balance": 100,
    }
    party_response = api_client.post(
        f"{base_url}/api/parties",
        headers=_auth_headers(token),
        json=party_payload,
    )
    assert party_response.status_code == 200
    party_data = party_response.json()
    assert party_data["name"] == party_payload["name"]
    assert isinstance(party_data["id"], str)


def test_owner_data_endpoints_load(api_client, base_url):
    _, auth_data = _register_owner(api_client, base_url)
    token = auth_data["token"]

    activate_response = api_client.post(
        f"{base_url}/api/subscriptions/activate",
        headers=_auth_headers(token),
        json={"plan_id": "starter", "billing_cycle": "monthly", "promo_code": None},
    )
    assert activate_response.status_code == 200

    endpoints = [
        "/api/parties",
        "/api/inventory",
        "/api/purchase-orders",
        "/api/bills",
        "/api/users",
    ]
    for endpoint in endpoints:
        response = api_client.get(f"{base_url}{endpoint}", headers=_auth_headers(token))
        assert response.status_code == 200
        assert isinstance(response.json(), list)


def test_super_admin_promo_code_management(api_client, base_url):
    login_response = api_client.post(
        f"{base_url}/api/auth/login",
        json={"email": "admin@mybillbook.dev", "password": "admin123"},
    )
    assert login_response.status_code == 200
    admin_token = login_response.json()["token"]

    promo_code = f"TESTPROMO{uuid.uuid4().hex[:6].upper()}"
    create_response = api_client.post(
        f"{base_url}/api/admin/promo-codes",
        headers=_auth_headers(admin_token),
        json={
            "code": promo_code,
            "discount_type": "percent",
            "discount_value": 10,
            "usage_limit": 50,
            "min_amount": 100,
            "expires_at": None,
            "is_active": True,
        },
    )
    assert create_response.status_code == 200
    create_data = create_response.json()
    assert create_data["code"] == promo_code
    assert create_data["discount_type"] == "percent"

    list_response = api_client.get(
        f"{base_url}/api/admin/promo-codes",
        headers=_auth_headers(admin_token),
    )
    assert list_response.status_code == 200
    promos = list_response.json()
    assert isinstance(promos, list)
    assert any(p["id"] == create_data["id"] for p in promos)
