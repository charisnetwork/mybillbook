from datetime import datetime, timezone
import logging
import os
from pathlib import Path
from typing import List, Literal, Optional
import uuid

from dotenv import load_dotenv
from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query
from jose import JWTError, jwt
from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext
from pydantic import BaseModel, ConfigDict, EmailStr
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]
jwt_secret = os.environ["JWT_SECRET"]
jwt_algorithm = "HS256"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

SUBSCRIPTION_PLANS = {
    "starter": {
        "name": "Starter",
        "monthly": 999,
        "yearly": 9999,
        "features": ["Unlimited Bills", "Party Management", "Inventory Management"],
    },
    "growth": {
        "name": "Growth",
        "monthly": 1999,
        "yearly": 19999,
        "features": ["Everything in Starter", "Purchase Orders", "Advanced Reports"],
    },
    "enterprise": {
        "name": "Enterprise",
        "monthly": 3999,
        "yearly": 39999,
        "features": ["Everything in Growth", "Multi-Branch Insights", "Dedicated Support"],
    },
}

app = FastAPI()
api_router = APIRouter(prefix="/api")


class UserPublic(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    full_name: str
    email: EmailStr
    role: Literal["owner", "staff", "super_admin"]
    business_id: Optional[str] = None
    business_name: Optional[str] = None


class AuthResponse(BaseModel):
    token: str
    user: UserPublic


class RegisterOwnerInput(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    business_name: str
    gstin: Optional[str] = None


class RegisterStaffInput(BaseModel):
    full_name: str
    email: EmailStr
    password: str


class LoginInput(BaseModel):
    email: EmailStr
    password: str


class PartyCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    gstin: Optional[str] = None
    address: Optional[str] = None
    balance_type: Literal["receivable", "payable"] = "receivable"
    current_balance: float = 0


class PartyUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    gstin: Optional[str] = None
    address: Optional[str] = None
    balance_type: Optional[Literal["receivable", "payable"]] = None
    current_balance: Optional[float] = None


class InventoryCreate(BaseModel):
    name: str
    sku: str
    unit: str = "pcs"
    purchase_price: float = 0
    selling_price: float = 0
    stock_quantity: float = 0
    low_stock_threshold: float = 10


class InventoryUpdate(BaseModel):
    name: Optional[str] = None
    sku: Optional[str] = None
    unit: Optional[str] = None
    purchase_price: Optional[float] = None
    selling_price: Optional[float] = None
    stock_quantity: Optional[float] = None
    low_stock_threshold: Optional[float] = None


class PurchaseOrderItemInput(BaseModel):
    inventory_id: str
    quantity: float
    unit_price: float


class PurchaseOrderCreate(BaseModel):
    supplier_party_id: str
    notes: Optional[str] = None
    items: List[PurchaseOrderItemInput]


class BillItemInput(BaseModel):
    inventory_id: str
    quantity: float
    unit_price: float


class BillCreate(BaseModel):
    party_id: str
    notes: Optional[str] = None
    items: List[BillItemInput]
    status: Literal["paid", "unpaid"] = "paid"


class SubscriptionActivateInput(BaseModel):
    plan_id: Literal["starter", "growth", "enterprise"]
    billing_cycle: Literal["monthly", "yearly"]
    promo_code: Optional[str] = None


class PromoCodeCreate(BaseModel):
    code: str
    discount_type: Literal["percent", "flat"]
    discount_value: float
    usage_limit: int = 100
    min_amount: float = 0
    expires_at: Optional[str] = None
    is_active: bool = True


class PromoCodeUpdate(BaseModel):
    discount_type: Optional[Literal["percent", "flat"]] = None
    discount_value: Optional[float] = None
    usage_limit: Optional[int] = None
    min_amount: Optional[float] = None
    expires_at: Optional[str] = None
    is_active: Optional[bool] = None


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    return pwd_context.verify(password, password_hash)


def create_token(user_id: str, role: str, business_id: Optional[str]) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "business_id": business_id,
        "iat": int(datetime.now(timezone.utc).timestamp()),
    }
    return jwt.encode(payload, jwt_secret, algorithm=jwt_algorithm)


async def get_current_user(authorization: str = Header(...)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, jwt_secret, algorithms=[jwt_algorithm])
    except JWTError as exc:
        raise HTTPException(status_code=401, detail="Invalid token") from exc

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    user = await db.users.find_one({"id": user_id}, {"_id": 0, "password_hash": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


def require_roles(roles: List[str]):
    async def validator(current_user=Depends(get_current_user)):
        if current_user["role"] not in roles:
            raise HTTPException(status_code=403, detail="Permission denied")
        return current_user

    return validator


def ensure_business_scope(current_user: dict):
    if current_user["role"] == "super_admin":
        raise HTTPException(status_code=403, detail="Super admin cannot access business records")


async def get_party_or_404(business_id: str, party_id: str):
    party = await db.parties.find_one({"business_id": business_id, "id": party_id}, {"_id": 0})
    if not party:
        raise HTTPException(status_code=404, detail="Party not found")
    return party


async def get_inventory_or_404(business_id: str, inventory_id: str):
    item = await db.inventory.find_one({"business_id": business_id, "id": inventory_id}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    return item


async def apply_promo_code(code: Optional[str], amount: float):
    if not code:
        return None, 0.0

    promo = await db.promo_codes.find_one({"code": code.strip().upper(), "is_active": True}, {"_id": 0})
    if not promo:
        raise HTTPException(status_code=404, detail="Promo code not found or inactive")

    if promo.get("usage_limit", 0) <= promo.get("used_count", 0):
        raise HTTPException(status_code=400, detail="Promo usage limit reached")
    if amount < promo.get("min_amount", 0):
        raise HTTPException(status_code=400, detail="Amount too low for this promo code")

    expiry = parse_iso(promo.get("expires_at"))
    if expiry and expiry < datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="Promo code has expired")

    discount = 0.0
    if promo["discount_type"] == "percent":
        discount = round((amount * promo["discount_value"]) / 100, 2)
    else:
        discount = round(promo["discount_value"], 2)

    return promo, min(discount, amount)


async def get_valid_active_subscription(business_id: str):
    subscription = await db.subscriptions.find_one(
        {"business_id": business_id, "status": "active"},
        {"_id": 0},
        sort=[("created_at", -1)],
    )
    if not subscription:
        return None

    expires_at = parse_iso(subscription.get("expires_at"))
    if expires_at and expires_at < datetime.now(timezone.utc):
        await db.subscriptions.update_one(
            {"id": subscription["id"]},
            {"$set": {"status": "expired", "updated_at": utc_now_iso()}},
        )
        return None

    if subscription.get("payment_status") not in ["MOCKED_SUCCESS", "SUCCESS"]:
        return None

    return subscription


async def require_active_subscription(current_user: dict):
    ensure_business_scope(current_user)
    subscription = await get_valid_active_subscription(current_user["business_id"])
    if not subscription:
        raise HTTPException(
            status_code=402,
            detail="Active subscription with successful payment is required for create/update actions",
        )
    return subscription


@api_router.get("/")
async def root():
    return {"message": "MyBillBook API is running"}


@api_router.post("/auth/register-owner", response_model=AuthResponse)
async def register_owner(input_data: RegisterOwnerInput):
    existing = await db.users.find_one({"email": input_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    business_id = str(uuid.uuid4())
    owner_id = str(uuid.uuid4())
    created_at = utc_now_iso()

    business_doc = {
        "id": business_id,
        "name": input_data.business_name,
        "gstin": input_data.gstin,
        "created_at": created_at,
    }
    user_doc = {
        "id": owner_id,
        "full_name": input_data.full_name,
        "email": input_data.email,
        "password_hash": hash_password(input_data.password),
        "role": "owner",
        "business_id": business_id,
        "business_name": input_data.business_name,
        "created_at": created_at,
    }

    await db.businesses.insert_one(dict(business_doc))
    await db.users.insert_one(dict(user_doc))

    token = create_token(owner_id, "owner", business_id)
    return AuthResponse(token=token, user=UserPublic(**{k: v for k, v in user_doc.items() if k != "password_hash"}))


@api_router.post("/auth/login", response_model=AuthResponse)
async def login(input_data: LoginInput):
    user = await db.users.find_one({"email": input_data.email}, {"_id": 0})
    if not user or not verify_password(input_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_token(user["id"], user["role"], user.get("business_id"))
    return AuthResponse(token=token, user=UserPublic(**{k: v for k, v in user.items() if k != "password_hash"}))


@api_router.get("/auth/me", response_model=UserPublic)
async def get_me(current_user=Depends(get_current_user)):
    return UserPublic(**current_user)


@api_router.post("/users/staff")
async def create_staff(input_data: RegisterStaffInput, current_user=Depends(require_roles(["owner"]))):
    await require_active_subscription(current_user)
    existing = await db.users.find_one({"email": input_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    staff_doc = {
        "id": str(uuid.uuid4()),
        "full_name": input_data.full_name,
        "email": input_data.email,
        "password_hash": hash_password(input_data.password),
        "role": "staff",
        "business_id": current_user["business_id"],
        "business_name": current_user.get("business_name"),
        "created_at": utc_now_iso(),
    }
    await db.users.insert_one(dict(staff_doc))
    return {
        "message": "Staff created",
        "staff": {
            "id": staff_doc["id"],
            "full_name": staff_doc["full_name"],
            "email": staff_doc["email"],
            "role": staff_doc["role"],
        },
    }


@api_router.get("/users")
async def list_users(current_user=Depends(require_roles(["owner"]))):
    users = await db.users.find(
        {"business_id": current_user["business_id"]},
        {"_id": 0, "password_hash": 0},
    ).to_list(1000)
    return users


@api_router.post("/parties")
async def create_party(input_data: PartyCreate, current_user=Depends(require_roles(["owner", "staff"]))):
    await require_active_subscription(current_user)
    party_doc = {
        "id": str(uuid.uuid4()),
        "business_id": current_user["business_id"],
        "name": input_data.name,
        "phone": input_data.phone,
        "gstin": input_data.gstin,
        "address": input_data.address,
        "balance_type": input_data.balance_type,
        "current_balance": input_data.current_balance,
        "created_at": utc_now_iso(),
    }
    await db.parties.insert_one(dict(party_doc))
    return party_doc


@api_router.get("/parties")
async def list_parties(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    return await db.parties.find({"business_id": current_user["business_id"]}, {"_id": 0}).to_list(1000)


@api_router.put("/parties/{party_id}")
async def update_party(
    party_id: str,
    input_data: PartyUpdate,
    current_user=Depends(require_roles(["owner", "staff"])),
):
    await require_active_subscription(current_user)
    await get_party_or_404(current_user["business_id"], party_id)
    update_data = input_data.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields provided")
    update_data["updated_at"] = utc_now_iso()
    await db.parties.update_one(
        {"business_id": current_user["business_id"], "id": party_id},
        {"$set": update_data},
    )
    return await db.parties.find_one(
        {"business_id": current_user["business_id"], "id": party_id},
        {"_id": 0},
    )


@api_router.delete("/parties/{party_id}")
async def delete_party(party_id: str, current_user=Depends(require_roles(["owner", "staff"]))):
    await require_active_subscription(current_user)
    result = await db.parties.delete_one({"business_id": current_user["business_id"], "id": party_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Party not found")
    return {"message": "Party deleted"}


@api_router.post("/inventory")
async def create_inventory(input_data: InventoryCreate, current_user=Depends(require_roles(["owner", "staff"]))):
    await require_active_subscription(current_user)
    existing = await db.inventory.find_one(
        {"business_id": current_user["business_id"], "sku": input_data.sku},
        {"_id": 0},
    )
    if existing:
        raise HTTPException(status_code=400, detail="SKU already exists")

    item_doc = {
        "id": str(uuid.uuid4()),
        "business_id": current_user["business_id"],
        "name": input_data.name,
        "sku": input_data.sku,
        "unit": input_data.unit,
        "purchase_price": input_data.purchase_price,
        "selling_price": input_data.selling_price,
        "stock_quantity": input_data.stock_quantity,
        "low_stock_threshold": input_data.low_stock_threshold,
        "created_at": utc_now_iso(),
    }
    await db.inventory.insert_one(dict(item_doc))
    return item_doc


@api_router.get("/inventory")
async def list_inventory(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    return await db.inventory.find({"business_id": current_user["business_id"]}, {"_id": 0}).to_list(1000)


@api_router.put("/inventory/{item_id}")
async def update_inventory(
    item_id: str,
    input_data: InventoryUpdate,
    current_user=Depends(require_roles(["owner", "staff"])),
):
    await require_active_subscription(current_user)
    await get_inventory_or_404(current_user["business_id"], item_id)
    update_data = input_data.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields provided")
    update_data["updated_at"] = utc_now_iso()
    await db.inventory.update_one(
        {"business_id": current_user["business_id"], "id": item_id},
        {"$set": update_data},
    )
    return await db.inventory.find_one(
        {"business_id": current_user["business_id"], "id": item_id},
        {"_id": 0},
    )


@api_router.delete("/inventory/{item_id}")
async def delete_inventory(item_id: str, current_user=Depends(require_roles(["owner", "staff"]))):
    await require_active_subscription(current_user)
    result = await db.inventory.delete_one({"business_id": current_user["business_id"], "id": item_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    return {"message": "Inventory item deleted"}


@api_router.post("/purchase-orders")
async def create_purchase_order(
    input_data: PurchaseOrderCreate,
    current_user=Depends(require_roles(["owner", "staff"])),
):
    await require_active_subscription(current_user)
    await get_party_or_404(current_user["business_id"], input_data.supplier_party_id)

    po_items = []
    total_amount = 0.0
    for line in input_data.items:
        item = await get_inventory_or_404(current_user["business_id"], line.inventory_id)
        line_total = round(line.quantity * line.unit_price, 2)
        total_amount += line_total
        po_items.append(
            {
                "inventory_id": item["id"],
                "inventory_name": item["name"],
                "quantity": line.quantity,
                "unit_price": line.unit_price,
                "line_total": line_total,
            }
        )

    po_doc = {
        "id": str(uuid.uuid4()),
        "business_id": current_user["business_id"],
        "supplier_party_id": input_data.supplier_party_id,
        "notes": input_data.notes,
        "items": po_items,
        "status": "ordered",
        "total_amount": round(total_amount, 2),
        "created_by": current_user["id"],
        "created_at": utc_now_iso(),
    }
    await db.purchase_orders.insert_one(dict(po_doc))
    return po_doc


@api_router.get("/purchase-orders")
async def list_purchase_orders(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    return await db.purchase_orders.find(
        {"business_id": current_user["business_id"]},
        {"_id": 0},
    ).to_list(1000)


@api_router.post("/purchase-orders/{purchase_order_id}/receive")
async def receive_purchase_order(
    purchase_order_id: str,
    current_user=Depends(require_roles(["owner", "staff"])),
):
    await require_active_subscription(current_user)
    order = await db.purchase_orders.find_one(
        {"business_id": current_user["business_id"], "id": purchase_order_id},
        {"_id": 0},
    )
    if not order:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    if order["status"] == "received":
        return {"message": "Purchase order already received"}

    for line in order["items"]:
        item = await get_inventory_or_404(current_user["business_id"], line["inventory_id"])
        await db.inventory.update_one(
            {"business_id": current_user["business_id"], "id": line["inventory_id"]},
            {"$set": {"stock_quantity": item["stock_quantity"] + line["quantity"], "updated_at": utc_now_iso()}},
        )

    await db.purchase_orders.update_one(
        {"business_id": current_user["business_id"], "id": purchase_order_id},
        {"$set": {"status": "received", "received_at": utc_now_iso()}},
    )
    return {"message": "Purchase order received and stock updated"}


@api_router.post("/bills")
async def create_bill(input_data: BillCreate, current_user=Depends(require_roles(["owner", "staff"]))):
    await require_active_subscription(current_user)
    await get_party_or_404(current_user["business_id"], input_data.party_id)

    bill_items = []
    subtotal = 0.0
    for line in input_data.items:
        item = await get_inventory_or_404(current_user["business_id"], line.inventory_id)
        if item["stock_quantity"] < line.quantity:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {item['name']}")

        line_total = round(line.quantity * line.unit_price, 2)
        subtotal += line_total
        bill_items.append(
            {
                "inventory_id": item["id"],
                "inventory_name": item["name"],
                "quantity": line.quantity,
                "unit_price": line.unit_price,
                "line_total": line_total,
            }
        )
        await db.inventory.update_one(
            {"business_id": current_user["business_id"], "id": item["id"]},
            {"$set": {"stock_quantity": round(item["stock_quantity"] - line.quantity, 2), "updated_at": utc_now_iso()}},
        )

    gst_rate = 18
    gst_amount = round((subtotal * gst_rate) / 100, 2)
    total_amount = round(subtotal + gst_amount, 2)

    bill_doc = {
        "id": str(uuid.uuid4()),
        "business_id": current_user["business_id"],
        "party_id": input_data.party_id,
        "notes": input_data.notes,
        "status": input_data.status,
        "items": bill_items,
        "subtotal": round(subtotal, 2),
        "gst_rate": gst_rate,
        "gst_amount": gst_amount,
        "total_amount": total_amount,
        "created_by": current_user["id"],
        "created_at": utc_now_iso(),
    }
    await db.bills.insert_one(dict(bill_doc))
    return bill_doc


@api_router.get("/bills")
async def list_bills(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    return await db.bills.find({"business_id": current_user["business_id"]}, {"_id": 0}).to_list(1000)


@api_router.get("/dashboard/summary")
async def dashboard_summary(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    business_id = current_user["business_id"]
    subscription = await get_valid_active_subscription(business_id)
    now = datetime.now(timezone.utc)
    month_start = datetime(now.year, now.month, 1, tzinfo=timezone.utc)

    bills = await db.bills.find({"business_id": business_id}, {"_id": 0}).to_list(5000)
    purchase_orders = await db.purchase_orders.find({"business_id": business_id}, {"_id": 0}).to_list(5000)
    inventory = await db.inventory.find({"business_id": business_id}, {"_id": 0}).to_list(5000)
    parties = await db.parties.find({"business_id": business_id}, {"_id": 0}).to_list(5000)

    total_sales = round(sum(b.get("total_amount", 0) for b in bills), 2)
    month_sales = round(
        sum(
            b.get("total_amount", 0)
            for b in bills
            if (parse_iso(b.get("created_at")) or now) >= month_start
        ),
        2,
    )
    money_in = round(sum(b.get("total_amount", 0) for b in bills if b.get("status") == "paid"), 2)
    money_out = round(sum(po.get("total_amount", 0) for po in purchase_orders), 2)
    inventory_value = round(
        sum(item.get("purchase_price", 0) * item.get("stock_quantity", 0) for item in inventory),
        2,
    )
    low_stock_count = len(
        [item for item in inventory if item.get("stock_quantity", 0) <= item.get("low_stock_threshold", 0)]
    )

    monthly = {i: 0 for i in range(1, 13)}
    for bill in bills:
        dt = parse_iso(bill.get("created_at"))
        if dt and dt.year == now.year:
            monthly[dt.month] = round(monthly[dt.month] + bill.get("total_amount", 0), 2)

    sales_trend = [
        {"month": datetime(now.year, i, 1, tzinfo=timezone.utc).strftime("%b"), "sales": monthly[i]}
        for i in range(1, 13)
    ]

    return {
        "total_sales": total_sales,
        "month_sales": month_sales,
        "money_in": money_in,
        "money_out": money_out,
        "inventory_value": inventory_value,
        "low_stock_count": low_stock_count,
        "total_parties": len(parties),
        "total_bills": len(bills),
        "sales_trend": sales_trend,
        "has_active_subscription": bool(subscription),
        "subscription_plan": subscription.get("plan_name") if subscription else None,
        "subscription_expires_at": subscription.get("expires_at") if subscription else None,
    }


@api_router.get("/subscriptions/plans")
async def list_plans(current_user=Depends(require_roles(["owner", "staff", "super_admin"]))):
    _ = current_user
    return [
        {
            "id": plan_id,
            "name": plan["name"],
            "monthly": plan["monthly"],
            "yearly": plan["yearly"],
            "features": plan["features"],
        }
        for plan_id, plan in SUBSCRIPTION_PLANS.items()
    ]


@api_router.post("/subscriptions/activate")
async def activate_subscription(
    input_data: SubscriptionActivateInput,
    current_user=Depends(require_roles(["owner"])),
):
    ensure_business_scope(current_user)
    plan = SUBSCRIPTION_PLANS[input_data.plan_id]
    amount = float(plan[input_data.billing_cycle])
    promo, discount_amount = await apply_promo_code(input_data.promo_code, amount)
    final_amount = round(amount - discount_amount, 2)

    now = datetime.now(timezone.utc)
    if input_data.billing_cycle == "monthly":
        next_month = 1 if now.month == 12 else now.month + 1
        next_year = now.year + (1 if now.month == 12 else 0)
        expires_at = datetime(next_year, next_month, min(now.day, 28), tzinfo=timezone.utc)
    else:
        expires_at = datetime(now.year + 1, now.month, min(now.day, 28), tzinfo=timezone.utc)

    await db.subscriptions.update_many(
        {"business_id": current_user["business_id"], "status": "active"},
        {"$set": {"status": "expired", "updated_at": utc_now_iso()}},
    )

    subscription_doc = {
        "id": str(uuid.uuid4()),
        "business_id": current_user["business_id"],
        "plan_id": input_data.plan_id,
        "plan_name": plan["name"],
        "billing_cycle": input_data.billing_cycle,
        "amount": amount,
        "discount_amount": discount_amount,
        "final_amount": final_amount,
        "promo_code": promo["code"] if promo else None,
        "payment_status": "MOCKED_SUCCESS",
        "payment_reference": f"MOCK-{str(uuid.uuid4())[:8].upper()}",
        "status": "active",
        "started_at": now.isoformat(),
        "expires_at": expires_at.isoformat(),
        "created_at": utc_now_iso(),
    }
    await db.subscriptions.insert_one(dict(subscription_doc))

    if promo:
        await db.promo_codes.update_one(
            {"id": promo["id"]},
            {"$set": {"used_count": promo.get("used_count", 0) + 1, "updated_at": utc_now_iso()}},
        )

    return subscription_doc


@api_router.get("/subscriptions/current")
async def current_subscription(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    subscription = await get_valid_active_subscription(current_user["business_id"])
    return subscription or {"message": "No active subscription"}


@api_router.get("/subscriptions/access-status")
async def subscription_access_status(current_user=Depends(require_roles(["owner", "staff"]))):
    ensure_business_scope(current_user)
    subscription = await get_valid_active_subscription(current_user["business_id"])
    return {
        "has_active_subscription": bool(subscription),
        "subscription": subscription,
        "message": "Access enabled" if subscription else "Read-only mode: activate subscription to add/edit data",
    }


@api_router.post("/admin/promo-codes")
async def create_promo(input_data: PromoCodeCreate, current_user=Depends(require_roles(["super_admin"]))):
    promo_doc = {
        "id": str(uuid.uuid4()),
        "code": input_data.code.strip().upper(),
        "discount_type": input_data.discount_type,
        "discount_value": input_data.discount_value,
        "usage_limit": input_data.usage_limit,
        "used_count": 0,
        "min_amount": input_data.min_amount,
        "expires_at": input_data.expires_at,
        "is_active": input_data.is_active,
        "created_by": current_user["id"],
        "created_at": utc_now_iso(),
    }
    existing = await db.promo_codes.find_one({"code": promo_doc["code"]}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Promo code already exists")
    await db.promo_codes.insert_one(dict(promo_doc))
    return promo_doc


@api_router.get("/admin/promo-codes")
async def list_promo_codes(current_user=Depends(require_roles(["super_admin"]))):
    _ = current_user
    return await db.promo_codes.find({}, {"_id": 0}).to_list(1000)


@api_router.put("/admin/promo-codes/{promo_id}")
async def update_promo(
    promo_id: str,
    input_data: PromoCodeUpdate,
    current_user=Depends(require_roles(["super_admin"])),
):
    _ = current_user
    update_data = input_data.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields provided")
    update_data["updated_at"] = utc_now_iso()

    result = await db.promo_codes.update_one({"id": promo_id}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Promo code not found")
    return await db.promo_codes.find_one({"id": promo_id}, {"_id": 0})


@api_router.get("/admin/analytics")
async def admin_analytics(
    period: Literal["month", "year"] = Query("month"),
    current_user=Depends(require_roles(["super_admin"])),
):
    _ = current_user
    now = datetime.now(timezone.utc)
    start = datetime(now.year, now.month, 1, tzinfo=timezone.utc) if period == "month" else datetime(now.year, 1, 1, tzinfo=timezone.utc)

    all_bills = await db.bills.find({}, {"_id": 0}).to_list(10000)
    all_subscriptions = await db.subscriptions.find({}, {"_id": 0}).to_list(10000)
    all_promos = await db.promo_codes.find({}, {"_id": 0}).to_list(1000)
    all_businesses = await db.businesses.find({}, {"_id": 0}).to_list(10000)

    filtered_bills = [b for b in all_bills if (parse_iso(b.get("created_at")) or now) >= start]
    filtered_subscriptions = [s for s in all_subscriptions if (parse_iso(s.get("created_at")) or now) >= start]

    billing_sales = round(sum(b.get("total_amount", 0) for b in filtered_bills), 2)
    subscription_sales = round(sum(s.get("final_amount", 0) for s in filtered_subscriptions), 2)

    monthly = {i: 0 for i in range(1, 13)}
    for bill in all_bills:
        dt = parse_iso(bill.get("created_at"))
        if dt and dt.year == now.year:
            monthly[dt.month] = round(monthly[dt.month] + bill.get("total_amount", 0), 2)

    sales_trend = [
        {"month": datetime(now.year, i, 1, tzinfo=timezone.utc).strftime("%b"), "sales": monthly[i]}
        for i in range(1, 13)
    ]

    promo_usage = [
        {
            "id": promo["id"],
            "code": promo["code"],
            "used_count": promo.get("used_count", 0),
            "usage_limit": promo.get("usage_limit", 0),
            "is_active": promo.get("is_active", False),
        }
        for promo in all_promos
    ]

    return {
        "period": period,
        "total_sales": round(billing_sales + subscription_sales, 2),
        "billing_sales": billing_sales,
        "subscription_sales": subscription_sales,
        "total_businesses": len(all_businesses),
        "bills_count": len(filtered_bills),
        "sales_trend": sales_trend,
        "promo_usage": promo_usage,
    }


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


@app.on_event("startup")
async def seed_super_admin():
    admin = await db.users.find_one({"role": "super_admin"}, {"_id": 0})
    if not admin:
        admin_doc = {
            "id": str(uuid.uuid4()),
            "full_name": "System Super Admin",
            "email": "admin@mybillbook.dev",
            "password_hash": hash_password("admin123"),
            "role": "super_admin",
            "business_id": None,
            "business_name": "Developer Panel",
            "created_at": utc_now_iso(),
        }
        await db.users.insert_one(dict(admin_doc))
        logger.info("Seeded default super admin")

    promo = await db.promo_codes.find_one({"code": "WELCOME20"}, {"_id": 0})
    if not promo:
        promo_doc = {
            "id": str(uuid.uuid4()),
            "code": "WELCOME20",
            "discount_type": "percent",
            "discount_value": 20,
            "usage_limit": 1000,
            "used_count": 0,
            "min_amount": 500,
            "expires_at": None,
            "is_active": True,
            "created_by": "system",
            "created_at": utc_now_iso(),
        }
        await db.promo_codes.insert_one(dict(promo_doc))
        logger.info("Seeded default promo code")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()