import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const InventoryPage = ({ hasActiveSubscription }) => {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    name: "",
    sku: "",
    unit: "pcs",
    purchase_price: 0,
    selling_price: 0,
    stock_quantity: 0,
    low_stock_threshold: 10,
  });

  const fetchInventory = async () => {
    const response = await api.get("/inventory");
    setItems(response.data || []);
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  const handleCreateItem = async (event) => {
    event.preventDefault();
    await api.post("/inventory", {
      ...form,
      purchase_price: Number(form.purchase_price || 0),
      selling_price: Number(form.selling_price || 0),
      stock_quantity: Number(form.stock_quantity || 0),
      low_stock_threshold: Number(form.low_stock_threshold || 0),
    });
    setForm({ name: "", sku: "", unit: "pcs", purchase_price: 0, selling_price: 0, stock_quantity: 0, low_stock_threshold: 10 });
    fetchInventory();
  };

  const handleDeleteItem = async (itemId) => {
    await api.delete(`/inventory/${itemId}`);
    fetchInventory();
  };

  return (
    <div className="space-y-6" data-testid="inventory-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="inventory-page-title">Inventory</h1>

      {!hasActiveSubscription ? (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" data-testid="inventory-subscription-lock-message">
          Read-only mode: activate subscription to add, edit or delete inventory.
        </div>
      ) : null}

      <Card data-testid="create-inventory-card">
        <CardHeader>
          <CardTitle data-testid="create-inventory-title">Add Inventory Item</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateItem} className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4" data-testid="create-inventory-form">
            <div className="space-y-2">
              <Label htmlFor="inventory-name">Name</Label>
              <Input id="inventory-name" disabled={!hasActiveSubscription} required value={form.name} data-testid="inventory-name-input" onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-sku">SKU</Label>
              <Input id="inventory-sku" disabled={!hasActiveSubscription} required value={form.sku} data-testid="inventory-sku-input" onChange={(e) => setForm((p) => ({ ...p, sku: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-unit">Unit</Label>
              <Input id="inventory-unit" disabled={!hasActiveSubscription} value={form.unit} data-testid="inventory-unit-input" onChange={(e) => setForm((p) => ({ ...p, unit: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-stock">Stock Quantity</Label>
              <Input id="inventory-stock" disabled={!hasActiveSubscription} type="number" value={form.stock_quantity} data-testid="inventory-stock-input" onChange={(e) => setForm((p) => ({ ...p, stock_quantity: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-purchase-price">Purchase Price</Label>
              <Input id="inventory-purchase-price" disabled={!hasActiveSubscription} type="number" value={form.purchase_price} data-testid="inventory-purchase-price-input" onChange={(e) => setForm((p) => ({ ...p, purchase_price: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-selling-price">Selling Price</Label>
              <Input id="inventory-selling-price" disabled={!hasActiveSubscription} type="number" value={form.selling_price} data-testid="inventory-selling-price-input" onChange={(e) => setForm((p) => ({ ...p, selling_price: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inventory-low-stock">Low Stock Alert</Label>
              <Input id="inventory-low-stock" disabled={!hasActiveSubscription} type="number" value={form.low_stock_threshold} data-testid="inventory-low-stock-input" onChange={(e) => setForm((p) => ({ ...p, low_stock_threshold: e.target.value }))} />
            </div>
            <div className="flex items-end">
              <Button type="submit" disabled={!hasActiveSubscription} data-testid="create-inventory-submit-button">Save Item</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card data-testid="inventory-table-card">
        <CardHeader>
          <CardTitle data-testid="inventory-list-title">Stock Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="inventory-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="inventory-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Name</th>
                  <th className="p-3">SKU</th>
                  <th className="p-3 text-right">Stock</th>
                  <th className="p-3 text-right">Purchase</th>
                  <th className="p-3 text-right">Selling</th>
                  <th className="p-3 text-right">Low Stock</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-t" data-testid={`inventory-row-${item.id}`}>
                    <td className="p-3" data-testid={`inventory-name-${item.id}`}>{item.name || "-"}</td>
                    <td className="p-3" data-testid={`inventory-sku-${item.id}`}>{item.sku || "-"}</td>
                    <td className="p-3 text-right" data-testid={`inventory-stock-${item.id}`}>{item.stock_quantity || 0}</td>
                    <td className="p-3 text-right" data-testid={`inventory-purchase-${item.id}`}>{formatCurrency(item.purchase_price)}</td>
                    <td className="p-3 text-right" data-testid={`inventory-selling-${item.id}`}>{formatCurrency(item.selling_price)}</td>
                    <td className="p-3 text-right" data-testid={`inventory-low-stock-${item.id}`}>{item.low_stock_threshold || 0}</td>
                    <td className="p-3">
                      <Button variant="outline" disabled={!hasActiveSubscription} onClick={() => handleDeleteItem(item.id)} data-testid={`inventory-delete-button-${item.id}`}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
