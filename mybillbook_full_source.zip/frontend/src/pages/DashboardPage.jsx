import { useEffect, useState } from "react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const defaultSummary = {
  total_sales: 0,
  month_sales: 0,
  money_in: 0,
  money_out: 0,
  inventory_value: 0,
  low_stock_count: 0,
  total_parties: 0,
  total_bills: 0,
  sales_trend: [],
};

export const DashboardPage = ({ subscriptionGate }) => {
  const [summary, setSummary] = useState(defaultSummary);
  const [loading, setLoading] = useState(true);

  const fetchSummary = async () => {
    setLoading(true);
    try {
      const response = await api.get("/dashboard/summary");
      setSummary({ ...defaultSummary, ...response.data });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, []);

  const cards = [
    { label: "Total Sales", value: formatCurrency(summary.total_sales), testid: "kpi-total-sales" },
    { label: "This Month", value: formatCurrency(summary.month_sales), testid: "kpi-month-sales" },
    { label: "Money In", value: formatCurrency(summary.money_in), testid: "kpi-money-in" },
    { label: "Money Out", value: formatCurrency(summary.money_out), testid: "kpi-money-out" },
    { label: "Inventory Value", value: formatCurrency(summary.inventory_value), testid: "kpi-inventory-value" },
    { label: "Low Stock Items", value: summary.low_stock_count, testid: "kpi-low-stock" },
    { label: "Total Parties", value: summary.total_parties, testid: "kpi-total-parties" },
    { label: "Total Bills", value: summary.total_bills, testid: "kpi-total-bills" },
  ];

  return (
    <div className="space-y-6" data-testid="dashboard-page">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="dashboard-page-title">
          Business Dashboard
        </h1>
        <Button onClick={fetchSummary} data-testid="dashboard-refresh-button">
          Refresh Dashboard
        </Button>
      </div>

      <Card
        className={`border ${subscriptionGate?.has_active_subscription ? "border-emerald-200 bg-emerald-50" : "border-amber-200 bg-amber-50"}`}
        data-testid="dashboard-subscription-status-card"
      >
        <CardContent className="pt-6">
          <p className="text-sm text-slate-700" data-testid="dashboard-subscription-status-text">
            {subscriptionGate?.has_active_subscription
              ? `Subscription active: ${subscriptionGate?.subscription?.plan_name || "Plan active"}`
              : "Subscription inactive: add/edit features are locked until payment confirmation."}
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4" data-testid="dashboard-kpi-grid">
        {cards.map((card) => (
          <Card key={card.label} className="fade-in-up bg-white">
            <CardHeader className="pb-1">
              <CardTitle className="text-sm text-slate-600">{card.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="display-font text-2xl font-bold text-slate-900" data-testid={card.testid}>
                {loading ? "..." : card.value}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-white" data-testid="dashboard-chart-card">
        <CardHeader>
          <CardTitle data-testid="dashboard-sales-trend-title">Yearly Sales Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full" data-testid="dashboard-sales-trend-chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={summary.sales_trend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="sales" stroke="#2563eb" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
