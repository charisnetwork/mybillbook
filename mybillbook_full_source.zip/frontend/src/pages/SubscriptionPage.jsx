import { useEffect, useState } from "react";
import { CheckCircle2, CreditCard, ShieldCheck } from "lucide-react";
import { api } from "@/lib/api";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const SubscriptionPage = ({ session, subscriptionGate, onSubscriptionActivated }) => {
  const [plans, setPlans] = useState([]);
  const [current, setCurrent] = useState(null);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentMessage, setPaymentMessage] = useState("");
  const [selection, setSelection] = useState({ plan_id: "starter", billing_cycle: "monthly", promo_code: "" });
  const [previewAmount, setPreviewAmount] = useState(0);

  const isOwner = session?.user?.role === "owner";

  const loadData = async () => {
    const [plansResponse, currentResponse] = await Promise.all([
      api.get("/subscriptions/plans"),
      api.get("/subscriptions/current"),
    ]);
    setPlans(plansResponse.data || []);
    setCurrent(currentResponse.data?.id ? currentResponse.data : null);
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const selectedPlan = plans.find((plan) => plan.id === selection.plan_id);
    if (!selectedPlan) {
      setPreviewAmount(0);
      return;
    }
    setPreviewAmount(selection.billing_cycle === "monthly" ? selectedPlan.monthly : selectedPlan.yearly);
  }, [plans, selection]);

  const handleStartMockPayment = () => {
    setPaymentMessage("");
    setPaymentDialogOpen(true);
  };

  const handleConfirmMockPayment = async () => {
    setPaymentLoading(true);
    setPaymentMessage("");
    try {
      const response = await api.post("/subscriptions/activate", {
        plan_id: selection.plan_id,
        billing_cycle: selection.billing_cycle,
        promo_code: selection.promo_code || null,
      });
      setPaymentMessage(`Payment successful. Ref: ${response.data.payment_reference}`);
      await loadData();
      await onSubscriptionActivated();
      setTimeout(() => setPaymentDialogOpen(false), 1200);
    } catch (requestError) {
      setPaymentMessage(requestError?.response?.data?.detail || "Mock payment failed. Please retry.");
    } finally {
      setPaymentLoading(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="subscription-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="subscription-page-title">Subscription Plans</h1>

      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50" data-testid="subscription-visibility-card">
        <CardContent className="flex flex-wrap items-center justify-between gap-4 pt-6">
          <div>
            <p className="display-font text-xl font-bold text-blue-900" data-testid="subscription-visibility-title">
              Subscription visible on every login
            </p>
            <p className="text-sm text-blue-800" data-testid="subscription-visibility-message">
              Users can always view records. Add/edit actions are enabled only after successful payment confirmation.
            </p>
          </div>
          <div className={`rounded-full px-4 py-2 text-xs font-semibold ${subscriptionGate?.has_active_subscription ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`} data-testid="subscription-visibility-status">
            {subscriptionGate?.has_active_subscription ? "ACTIVE" : "READ-ONLY MODE"}
          </div>
        </CardContent>
      </Card>

      {current ? (
        <Card className="border-emerald-200 bg-emerald-50" data-testid="current-subscription-card">
          <CardHeader>
            <CardTitle data-testid="current-subscription-title">Current Active Subscription</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700" data-testid="current-subscription-plan">Plan: {current.plan_name || "-"} ({current.billing_cycle || "-"})</p>
            <p className="text-sm text-slate-700" data-testid="current-subscription-expiry">Expires: {formatDateTime(current.expires_at)}</p>
            <p className="text-sm text-slate-700" data-testid="current-subscription-payment-status">
              Payment Status: {current.payment_status || "-"}
            </p>
            <p className="text-xs text-slate-500" data-testid="subscription-mocked-note">
              Payment reference is generated via mocked workflow for now.
            </p>
          </CardContent>
        </Card>
      ) : null}

      {!isOwner ? (
        <div className="rounded-md border border-slate-200 bg-slate-100 p-3 text-sm text-slate-700" data-testid="subscription-owner-only-message">
          Only owner can activate or upgrade subscription. Staff users can view plan details.
        </div>
      ) : null}

      <Card data-testid="subscription-selection-card">
        <CardHeader>
          <CardTitle data-testid="subscription-selection-title">Choose Plan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3" data-testid="subscription-plans-grid">
            {plans.map((plan) => (
              <button
                key={plan.id}
                type="button"
                onClick={() => setSelection((p) => ({ ...p, plan_id: plan.id }))}
                data-testid={`subscription-plan-card-${plan.id}`}
                className={`rounded-lg border p-4 text-left transition-colors ${
                  selection.plan_id === plan.id ? "border-blue-600 bg-blue-50" : "border-slate-200 bg-white"
                }`}
              >
                <p className="display-font text-xl font-bold text-slate-900" data-testid={`subscription-plan-name-${plan.id}`}>{plan.name}</p>
                <p className="text-sm text-slate-600" data-testid={`subscription-plan-monthly-${plan.id}`}>Monthly: {formatCurrency(plan.monthly)}</p>
                <p className="text-sm text-slate-600" data-testid={`subscription-plan-yearly-${plan.id}`}>Yearly: {formatCurrency(plan.yearly)}</p>
                <ul className="mt-3 list-disc space-y-1 pl-4 text-xs text-slate-600" data-testid={`subscription-plan-features-${plan.id}`}>
                  {(plan.features || []).map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </button>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="billing-cycle">Billing Cycle</Label>
              <select
                id="billing-cycle"
                value={selection.billing_cycle}
                disabled={!isOwner}
                data-testid="subscription-billing-cycle-select"
                className="h-10 w-full rounded-md border border-slate-300 px-3"
                onChange={(e) => setSelection((p) => ({ ...p, billing_cycle: e.target.value }))}
              >
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="promo-code">Promo Code</Label>
              <Input
                id="promo-code"
                value={selection.promo_code}
                disabled={!isOwner}
                data-testid="subscription-promo-code-input"
                onChange={(e) => setSelection((p) => ({ ...p, promo_code: e.target.value }))}
                placeholder="Enter promo code (optional)"
              />
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4" data-testid="subscription-payment-preview-card">
            <p className="text-sm text-slate-600">Selected Amount</p>
            <p className="display-font text-3xl font-bold text-slate-900" data-testid="subscription-payment-preview-amount">
              {formatCurrency(previewAmount)}
            </p>
            <p className="mt-1 text-xs text-slate-500" data-testid="subscription-payment-preview-note">
              Promo discount is applied during checkout in mock payment gateway.
            </p>
          </div>

          <Button onClick={handleStartMockPayment} disabled={!isOwner} data-testid="activate-subscription-button">
            Open Mock Payment Gateway
          </Button>
        </CardContent>
      </Card>

      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent data-testid="mock-payment-dialog">
          <DialogHeader>
            <DialogTitle className="display-font flex items-center gap-2" data-testid="mock-payment-dialog-title">
              <CreditCard size={18} />
              Mock Payment Gateway
            </DialogTitle>
            <DialogDescription data-testid="mock-payment-dialog-description">
              Simulate payment confirmation to activate subscription and unlock add/edit actions.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4" data-testid="mock-payment-summary-card">
            <p className="text-sm text-slate-600">Plan</p>
            <p className="font-semibold text-slate-900" data-testid="mock-payment-summary-plan">{selection.plan_id.toUpperCase()} ({selection.billing_cycle})</p>
            <p className="text-sm text-slate-600">Amount</p>
            <p className="display-font text-2xl font-bold text-blue-700" data-testid="mock-payment-summary-amount">{formatCurrency(previewAmount)}</p>
            <p className="text-xs text-slate-500" data-testid="mock-payment-summary-promo">Promo: {selection.promo_code || "No promo"}</p>
            <div className="rounded-md bg-emerald-50 p-2 text-xs text-emerald-700" data-testid="mock-payment-security-note">
              <ShieldCheck size={14} className="mr-1 inline" />
              This is a safe mock gateway for local/product demo flow.
            </div>
          </div>

          {paymentMessage ? (
            <p className="rounded-md border border-blue-200 bg-blue-50 p-2 text-sm text-blue-700" data-testid="mock-payment-message">
              <CheckCircle2 size={14} className="mr-1 inline" />
              {paymentMessage}
            </p>
          ) : null}

          <DialogFooter>
            <Button variant="outline" onClick={() => setPaymentDialogOpen(false)} data-testid="mock-payment-cancel-button">
              Cancel
            </Button>
            <Button onClick={handleConfirmMockPayment} disabled={paymentLoading || !isOwner} data-testid="mock-payment-confirm-button">
              {paymentLoading ? "Processing..." : "Confirm Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
