import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const PurchaseOrdersPage = ({ hasActiveSubscription }) => {
  const [parties, setParties] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [orders, setOrders] = useState([]);
  const [form, setForm] = useState({ supplier_party_id: "", inventory_id: "", quantity: 1, unit_price: 0, notes: "" });

  const loadData = async () => {
    const [partiesResponse, inventoryResponse, ordersResponse] = await Promise.all([
      api.get("/parties"),
      api.get("/inventory"),
      api.get("/purchase-orders"),
    ]);
    setParties(partiesResponse.data || []);
    setInventory(inventoryResponse.data || []);
    setOrders(ordersResponse.data || []);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateOrder = async (event) => {
    event.preventDefault();
    await api.post("/purchase-orders", {
      supplier_party_id: form.supplier_party_id,
      notes: form.notes,
      items: [
        {
          inventory_id: form.inventory_id,
          quantity: Number(form.quantity),
          unit_price: Number(form.unit_price),
        },
      ],
    });
    setForm({ supplier_party_id: "", inventory_id: "", quantity: 1, unit_price: 0, notes: "" });
    loadData();
  };

  const handleReceive = async (orderId) => {
    await api.post(`/purchase-orders/${orderId}/receive`);
    loadData();
  };

  return (
    <div className="space-y-6" data-testid="purchase-orders-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="purchase-orders-page-title">Purchase Orders</h1>

      {!hasActiveSubscription ? (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" data-testid="purchase-orders-subscription-lock-message">
          Read-only mode: activate subscription to create PO or mark received.
        </div>
      ) : null}

      <Card data-testid="create-purchase-order-card">
        <CardHeader>
          <CardTitle data-testid="create-purchase-order-title">Create Purchase Order</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateOrder} className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="create-purchase-order-form">
            <div className="space-y-2">
              <Label htmlFor="po-party">Supplier Party</Label>
              <select id="po-party" disabled={!hasActiveSubscription} value={form.supplier_party_id} required data-testid="purchase-order-party-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, supplier_party_id: e.target.value }))}>
                <option value="">Select supplier</option>
                {parties.map((party) => (
                  <option key={party.id} value={party.id}>{party.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="po-item">Inventory Item</Label>
              <select id="po-item" disabled={!hasActiveSubscription} value={form.inventory_id} required data-testid="purchase-order-item-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, inventory_id: e.target.value }))}>
                <option value="">Select item</option>
                {inventory.map((item) => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="po-qty">Quantity</Label>
              <Input id="po-qty" disabled={!hasActiveSubscription} type="number" required value={form.quantity} data-testid="purchase-order-quantity-input" onChange={(e) => setForm((p) => ({ ...p, quantity: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="po-price">Unit Price</Label>
              <Input id="po-price" disabled={!hasActiveSubscription} type="number" required value={form.unit_price} data-testid="purchase-order-unit-price-input" onChange={(e) => setForm((p) => ({ ...p, unit_price: e.target.value }))} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="po-notes">Notes</Label>
              <Input id="po-notes" disabled={!hasActiveSubscription} value={form.notes} data-testid="purchase-order-notes-input" onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
            </div>
            <div className="flex items-end">
              <Button type="submit" disabled={!hasActiveSubscription} data-testid="purchase-order-submit-button">Create PO</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card data-testid="purchase-orders-table-card">
        <CardHeader>
          <CardTitle data-testid="purchase-orders-list-title">Purchase Order List</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="purchase-orders-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="purchase-orders-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">ID</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-right">Total</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-t" data-testid={`purchase-order-row-${order.id}`}>
                    <td className="p-3" data-testid={`purchase-order-id-${order.id}`}>{order.id.slice(0, 8)}</td>
                    <td className="p-3" data-testid={`purchase-order-status-${order.id}`}>{order.status}</td>
                    <td className="p-3" data-testid={`purchase-order-date-${order.id}`}>{formatDateTime(order.created_at)}</td>
                    <td className="p-3 text-right" data-testid={`purchase-order-total-${order.id}`}>{formatCurrency(order.total_amount)}</td>
                    <td className="p-3">
                      {order.status === "ordered" ? (
                        <Button variant="outline" disabled={!hasActiveSubscription} onClick={() => handleReceive(order.id)} data-testid={`purchase-order-receive-button-${order.id}`}>
                          Mark Received
                        </Button>
                      ) : (
                        <span className="text-emerald-600" data-testid={`purchase-order-received-badge-${order.id}`}>Received</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
