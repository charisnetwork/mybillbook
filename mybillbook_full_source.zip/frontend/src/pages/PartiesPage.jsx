import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const PartiesPage = ({ hasActiveSubscription }) => {
  const [parties, setParties] = useState([]);
  const [form, setForm] = useState({ name: "", phone: "", gstin: "", address: "", balance_type: "receivable", current_balance: 0 });

  const fetchParties = async () => {
    const response = await api.get("/parties");
    setParties(response.data || []);
  };

  useEffect(() => {
    fetchParties();
  }, []);

  const handleCreateParty = async (event) => {
    event.preventDefault();
    await api.post("/parties", { ...form, current_balance: Number(form.current_balance || 0) });
    setForm({ name: "", phone: "", gstin: "", address: "", balance_type: "receivable", current_balance: 0 });
    fetchParties();
  };

  const handleDeleteParty = async (partyId) => {
    await api.delete(`/parties/${partyId}`);
    fetchParties();
  };

  return (
    <div className="space-y-6" data-testid="parties-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="parties-page-title">Parties</h1>

      {!hasActiveSubscription ? (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" data-testid="parties-subscription-lock-message">
          Read-only mode: activate subscription to add, edit or delete parties.
        </div>
      ) : null}

      <Card data-testid="create-party-card">
        <CardHeader>
          <CardTitle data-testid="create-party-title">Add New Party</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateParty} className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="create-party-form">
            <div className="space-y-2">
              <Label htmlFor="party-name">Party Name</Label>
              <Input id="party-name" disabled={!hasActiveSubscription} required value={form.name} data-testid="party-name-input" onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="party-phone">Phone</Label>
              <Input id="party-phone" disabled={!hasActiveSubscription} value={form.phone} data-testid="party-phone-input" onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="party-gstin">GSTIN</Label>
              <Input id="party-gstin" disabled={!hasActiveSubscription} value={form.gstin} data-testid="party-gstin-input" onChange={(e) => setForm((p) => ({ ...p, gstin: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="party-address">Address</Label>
              <Input id="party-address" disabled={!hasActiveSubscription} value={form.address} data-testid="party-address-input" onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="party-balance-type">Balance Type</Label>
              <select id="party-balance-type" disabled={!hasActiveSubscription} value={form.balance_type} data-testid="party-balance-type-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, balance_type: e.target.value }))}>
                <option value="receivable">Receivable</option>
                <option value="payable">Payable</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="party-current-balance">Opening Balance</Label>
              <Input id="party-current-balance" disabled={!hasActiveSubscription} type="number" value={form.current_balance} data-testid="party-current-balance-input" onChange={(e) => setForm((p) => ({ ...p, current_balance: e.target.value }))} />
            </div>
            <div className="md:col-span-2 lg:col-span-3">
              <Button type="submit" disabled={!hasActiveSubscription} data-testid="create-party-submit-button">Save Party</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card data-testid="parties-table-card">
        <CardHeader>
          <CardTitle data-testid="parties-list-title">All Parties</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="parties-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="parties-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Name</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">GSTIN</th>
                  <th className="p-3">Balance Type</th>
                  <th className="p-3 text-right">Balance</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {parties.map((party) => (
                  <tr key={party.id} className="border-t" data-testid={`party-row-${party.id}`}>
                    <td className="p-3" data-testid={`party-name-${party.id}`}>{party.name || "-"}</td>
                    <td className="p-3" data-testid={`party-phone-${party.id}`}>{party.phone || "-"}</td>
                    <td className="p-3" data-testid={`party-gstin-${party.id}`}>{party.gstin || "-"}</td>
                    <td className="p-3" data-testid={`party-balance-type-${party.id}`}>{party.balance_type || "-"}</td>
                    <td className="p-3 text-right" data-testid={`party-balance-${party.id}`}>{formatCurrency(party.current_balance)}</td>
                    <td className="p-3">
                      <Button variant="outline" disabled={!hasActiveSubscription} onClick={() => handleDeleteParty(party.id)} data-testid={`party-delete-button-${party.id}`}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
