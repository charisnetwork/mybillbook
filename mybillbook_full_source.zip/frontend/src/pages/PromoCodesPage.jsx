import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const PromoCodesPage = () => {
  const [codes, setCodes] = useState([]);
  const [form, setForm] = useState({ code: "", discount_type: "percent", discount_value: 10, usage_limit: 100, min_amount: 0, expires_days: 30 });

  const fetchCodes = async () => {
    const response = await api.get("/admin/promo-codes");
    setCodes(response.data || []);
  };

  useEffect(() => {
    fetchCodes();
  }, []);

  const handleCreateCode = async (event) => {
    event.preventDefault();
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + Number(form.expires_days || 0));
    await api.post("/admin/promo-codes", {
      code: form.code,
      discount_type: form.discount_type,
      discount_value: Number(form.discount_value),
      usage_limit: Number(form.usage_limit),
      min_amount: Number(form.min_amount),
      expires_at: expiryDate.toISOString(),
      is_active: true,
    });
    setForm({ code: "", discount_type: "percent", discount_value: 10, usage_limit: 100, min_amount: 0, expires_days: 30 });
    fetchCodes();
  };

  const handleToggleActive = async (promo) => {
    await api.put(`/admin/promo-codes/${promo.id}`, { is_active: !promo.is_active });
    fetchCodes();
  };

  return (
    <div className="space-y-6" data-testid="promo-codes-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="promo-codes-page-title">Promo Code Management</h1>

      <Card data-testid="create-promo-card">
        <CardHeader>
          <CardTitle data-testid="create-promo-title">Create Promo Code</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3" onSubmit={handleCreateCode} data-testid="create-promo-form">
            <div className="space-y-2">
              <Label htmlFor="promo-code">Code</Label>
              <Input id="promo-code" required value={form.code} data-testid="promo-code-input" onChange={(e) => setForm((p) => ({ ...p, code: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="promo-type">Discount Type</Label>
              <select id="promo-type" value={form.discount_type} data-testid="promo-type-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, discount_type: e.target.value }))}>
                <option value="percent">Percent</option>
                <option value="flat">Flat</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="promo-value">Discount Value</Label>
              <Input id="promo-value" type="number" required value={form.discount_value} data-testid="promo-value-input" onChange={(e) => setForm((p) => ({ ...p, discount_value: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="promo-usage-limit">Usage Limit</Label>
              <Input id="promo-usage-limit" type="number" required value={form.usage_limit} data-testid="promo-usage-limit-input" onChange={(e) => setForm((p) => ({ ...p, usage_limit: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="promo-min-amount">Min Amount</Label>
              <Input id="promo-min-amount" type="number" required value={form.min_amount} data-testid="promo-min-amount-input" onChange={(e) => setForm((p) => ({ ...p, min_amount: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="promo-expiry-days">Expires In (days)</Label>
              <Input id="promo-expiry-days" type="number" required value={form.expires_days} data-testid="promo-expiry-days-input" onChange={(e) => setForm((p) => ({ ...p, expires_days: e.target.value }))} />
            </div>
            <div className="md:col-span-2 lg:col-span-3">
              <Button type="submit" data-testid="promo-submit-button">Create Promo Code</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card data-testid="promo-codes-table-card">
        <CardHeader>
          <CardTitle data-testid="promo-codes-list-title">Existing Promo Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="promo-codes-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="promo-codes-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Code</th>
                  <th className="p-3">Type</th>
                  <th className="p-3 text-right">Value</th>
                  <th className="p-3 text-right">Usage</th>
                  <th className="p-3">Expiry</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {codes.map((promo) => (
                  <tr key={promo.id} className="border-t" data-testid={`promo-row-${promo.id}`}>
                    <td className="p-3" data-testid={`promo-code-${promo.id}`}>{promo.code}</td>
                    <td className="p-3" data-testid={`promo-type-${promo.id}`}>{promo.discount_type}</td>
                    <td className="p-3 text-right" data-testid={`promo-value-${promo.id}`}>{promo.discount_value}</td>
                    <td className="p-3 text-right" data-testid={`promo-usage-${promo.id}`}>{promo.used_count}/{promo.usage_limit}</td>
                    <td className="p-3" data-testid={`promo-expiry-${promo.id}`}>{formatDateTime(promo.expires_at)}</td>
                    <td className="p-3" data-testid={`promo-status-${promo.id}`}>{promo.is_active ? "Active" : "Inactive"}</td>
                    <td className="p-3">
                      <Button variant="outline" onClick={() => handleToggleActive(promo)} data-testid={`promo-toggle-button-${promo.id}`}>
                        Toggle
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
