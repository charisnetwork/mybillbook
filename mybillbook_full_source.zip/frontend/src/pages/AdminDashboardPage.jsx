import { useEffect, useState } from "react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const AdminDashboardPage = () => {
  const [period, setPeriod] = useState("month");
  const [analytics, setAnalytics] = useState({
    total_sales: 0,
    billing_sales: 0,
    subscription_sales: 0,
    total_businesses: 0,
    bills_count: 0,
    sales_trend: [],
    promo_usage: [],
  });

  const fetchAnalytics = async (nextPeriod) => {
    const response = await api.get(`/admin/analytics?period=${nextPeriod}`);
    setAnalytics(response.data || {});
  };

  useEffect(() => {
    fetchAnalytics(period);
  }, [period]);

  return (
    <div className="space-y-6" data-testid="admin-dashboard-page">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="admin-dashboard-title">Super Admin Panel</h1>
        <select
          value={period}
          data-testid="admin-period-select"
          className="h-10 rounded-md border border-slate-300 px-3"
          onChange={(event) => setPeriod(event.target.value)}
        >
          <option value="month">This Month</option>
          <option value="year">This Year</option>
        </select>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5" data-testid="admin-kpi-grid">
        <Card><CardContent className="pt-6"><p className="text-xs text-slate-500">Total Sales</p><p className="display-font text-2xl font-bold" data-testid="admin-total-sales">{formatCurrency(analytics.total_sales)}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-xs text-slate-500">Billing Sales</p><p className="display-font text-2xl font-bold" data-testid="admin-billing-sales">{formatCurrency(analytics.billing_sales)}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-xs text-slate-500">Subscription Sales</p><p className="display-font text-2xl font-bold" data-testid="admin-subscription-sales">{formatCurrency(analytics.subscription_sales)}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-xs text-slate-500">Businesses</p><p className="display-font text-2xl font-bold" data-testid="admin-total-businesses">{analytics.total_businesses || 0}</p></CardContent></Card>
        <Card><CardContent className="pt-6"><p className="text-xs text-slate-500">Bills Count</p><p className="display-font text-2xl font-bold" data-testid="admin-bills-count">{analytics.bills_count || 0}</p></CardContent></Card>
      </div>

      <Card data-testid="admin-sales-trend-card">
        <CardHeader>
          <CardTitle data-testid="admin-sales-trend-title">Sales Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]" data-testid="admin-sales-trend-chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics.sales_trend || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="sales" stroke="#2563eb" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card data-testid="admin-promo-usage-card">
        <CardHeader>
          <CardTitle data-testid="admin-promo-usage-title">Promo Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="admin-promo-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="admin-promo-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Code</th>
                  <th className="p-3 text-right">Used</th>
                  <th className="p-3 text-right">Limit</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {(analytics.promo_usage || []).map((promo) => (
                  <tr key={promo.id} className="border-t" data-testid={`admin-promo-row-${promo.id}`}>
                    <td className="p-3" data-testid={`admin-promo-code-${promo.id}`}>{promo.code}</td>
                    <td className="p-3 text-right" data-testid={`admin-promo-used-${promo.id}`}>{promo.used_count}</td>
                    <td className="p-3 text-right" data-testid={`admin-promo-limit-${promo.id}`}>{promo.usage_limit}</td>
                    <td className="p-3" data-testid={`admin-promo-status-${promo.id}`}>{promo.is_active ? "Active" : "Inactive"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
