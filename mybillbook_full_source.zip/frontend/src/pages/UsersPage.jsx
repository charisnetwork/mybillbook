import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const UsersPage = ({ hasActiveSubscription }) => {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ full_name: "", email: "", password: "" });

  const fetchUsers = async () => {
    const response = await api.get("/users");
    setUsers(response.data || []);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateStaff = async (event) => {
    event.preventDefault();
    await api.post("/users/staff", form);
    setForm({ full_name: "", email: "", password: "" });
    fetchUsers();
  };

  return (
    <div className="space-y-6" data-testid="users-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="users-page-title">Staff Users</h1>

      {!hasActiveSubscription ? (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" data-testid="users-subscription-lock-message">
          Read-only mode: activate subscription to create staff users.
        </div>
      ) : null}

      <Card data-testid="create-staff-card">
        <CardHeader>
          <CardTitle data-testid="create-staff-title">Create Staff Login</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="grid grid-cols-1 gap-4 md:grid-cols-3" onSubmit={handleCreateStaff} data-testid="create-staff-form">
            <div className="space-y-2">
              <Label htmlFor="staff-name">Full Name</Label>
              <Input id="staff-name" disabled={!hasActiveSubscription} required value={form.full_name} data-testid="staff-name-input" onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="staff-email">Email</Label>
              <Input id="staff-email" disabled={!hasActiveSubscription} required type="email" value={form.email} data-testid="staff-email-input" onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="staff-password">Password</Label>
              <Input id="staff-password" disabled={!hasActiveSubscription} required type="password" value={form.password} data-testid="staff-password-input" onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))} />
            </div>
            <div className="md:col-span-3">
              <Button type="submit" disabled={!hasActiveSubscription} data-testid="create-staff-submit-button">Create Staff</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card data-testid="staff-list-card">
        <CardHeader>
          <CardTitle data-testid="staff-list-title">Business Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="staff-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="staff-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Name</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Role</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-t" data-testid={`staff-row-${user.id}`}>
                    <td className="p-3" data-testid={`staff-name-${user.id}`}>{user.full_name}</td>
                    <td className="p-3" data-testid={`staff-email-${user.id}`}>{user.email}</td>
                    <td className="p-3" data-testid={`staff-role-${user.id}`}>{user.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
