import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const BillsPage = ({ hasActiveSubscription }) => {
  const [parties, setParties] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [bills, setBills] = useState([]);
  const [lineItems, setLineItems] = useState([]);
  const [form, setForm] = useState({ party_id: "", inventory_id: "", quantity: 1, unit_price: 0, status: "paid", notes: "" });

  const loadData = async () => {
    const [partiesResponse, inventoryResponse, billsResponse] = await Promise.all([
      api.get("/parties"),
      api.get("/inventory"),
      api.get("/bills"),
    ]);
    setParties(partiesResponse.data || []);
    setInventory(inventoryResponse.data || []);
    setBills(billsResponse.data || []);
  };

  useEffect(() => {
    loadData();
  }, []);

  const cartTotal = useMemo(
    () => lineItems.reduce((sum, line) => sum + Number(line.quantity) * Number(line.unit_price), 0),
    [lineItems],
  );

  const handleAddLineItem = () => {
    if (!form.inventory_id) return;
    const selectedItem = inventory.find((item) => item.id === form.inventory_id);
    setLineItems((prev) => [
      ...prev,
      {
        inventory_id: form.inventory_id,
        inventory_name: selectedItem?.name || "-",
        quantity: Number(form.quantity),
        unit_price: Number(form.unit_price),
      },
    ]);
  };

  const handleCreateBill = async (event) => {
    event.preventDefault();
    await api.post("/bills", {
      party_id: form.party_id,
      status: form.status,
      notes: form.notes,
      items: lineItems.map((line) => ({
        inventory_id: line.inventory_id,
        quantity: Number(line.quantity),
        unit_price: Number(line.unit_price),
      })),
    });
    setForm({ party_id: "", inventory_id: "", quantity: 1, unit_price: 0, status: "paid", notes: "" });
    setLineItems([]);
    loadData();
  };

  return (
    <div className="space-y-6" data-testid="bills-page">
      <h1 className="display-font text-4xl font-bold text-slate-900" data-testid="bills-page-title">Bill Entry</h1>

      {!hasActiveSubscription ? (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" data-testid="bills-subscription-lock-message">
          Read-only mode: activate subscription to create new bills.
        </div>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-12">
        <Card className="lg:col-span-7" data-testid="create-bill-card">
          <CardHeader>
            <CardTitle data-testid="create-bill-title">Create Bill</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateBill} className="space-y-4" data-testid="create-bill-form">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="bill-party">Party</Label>
                  <select id="bill-party" disabled={!hasActiveSubscription} required value={form.party_id} data-testid="bill-party-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, party_id: e.target.value }))}>
                    <option value="">Select party</option>
                    {parties.map((party) => (
                      <option key={party.id} value={party.id}>{party.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bill-status">Status</Label>
                  <select id="bill-status" disabled={!hasActiveSubscription} value={form.status} data-testid="bill-status-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => setForm((p) => ({ ...p, status: e.target.value }))}>
                    <option value="paid">Paid</option>
                    <option value="unpaid">Unpaid</option>
                  </select>
                </div>
              </div>

              <div className="grid gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 md:grid-cols-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="bill-item">Item</Label>
                  <select id="bill-item" disabled={!hasActiveSubscription} value={form.inventory_id} data-testid="bill-item-select" className="h-10 w-full rounded-md border border-slate-300 px-3" onChange={(e) => {
                    const selected = inventory.find((item) => item.id === e.target.value);
                    setForm((p) => ({ ...p, inventory_id: e.target.value, unit_price: selected?.selling_price || 0 }));
                  }}>
                    <option value="">Select inventory item</option>
                    {inventory.map((item) => (
                      <option key={item.id} value={item.id}>{item.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bill-qty">Qty</Label>
                  <Input id="bill-qty" disabled={!hasActiveSubscription} type="number" value={form.quantity} data-testid="bill-quantity-input" onChange={(e) => setForm((p) => ({ ...p, quantity: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bill-price">Unit Price</Label>
                  <Input id="bill-price" disabled={!hasActiveSubscription} type="number" value={form.unit_price} data-testid="bill-unit-price-input" onChange={(e) => setForm((p) => ({ ...p, unit_price: e.target.value }))} />
                </div>
                <div className="md:col-span-4">
                  <Button type="button" disabled={!hasActiveSubscription} variant="outline" onClick={handleAddLineItem} data-testid="add-bill-line-item-button">
                    Add Line Item
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bill-notes">Notes</Label>
                <Input id="bill-notes" disabled={!hasActiveSubscription} value={form.notes} data-testid="bill-notes-input" onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
              </div>

              <Button type="submit" disabled={!hasActiveSubscription || lineItems.length === 0} data-testid="create-bill-submit-button">
                Generate Bill
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-5" data-testid="bill-cart-summary-card">
          <CardHeader>
            <CardTitle data-testid="bill-cart-summary-title">Bill Cart Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="max-h-72 space-y-2 overflow-auto" data-testid="bill-cart-items-list">
              {lineItems.map((line, index) => (
                <div key={`${line.inventory_id}-${index}`} className="rounded-md border border-slate-200 p-3" data-testid={`bill-cart-item-${index}`}>
                  <p className="font-medium text-slate-800" data-testid={`bill-cart-item-name-${index}`}>{line.inventory_name}</p>
                  <p className="text-xs text-slate-600" data-testid={`bill-cart-item-detail-${index}`}>
                    {line.quantity} x {formatCurrency(line.unit_price)}
                  </p>
                </div>
              ))}
            </div>
            <div className="rounded-md bg-blue-50 p-4">
              <p className="text-sm text-slate-700">Subtotal</p>
              <p className="display-font text-2xl font-bold text-blue-700" data-testid="bill-cart-subtotal">
                {formatCurrency(cartTotal)}
              </p>
              <p className="text-xs text-slate-500" data-testid="bill-cart-gst-note">GST and total will calculate on save.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card data-testid="bills-table-card">
        <CardHeader>
          <CardTitle data-testid="bills-list-title">Recent Bills</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="bills-table-wrapper">
            <table className="w-full text-left text-sm" data-testid="bills-table">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="p-3">Bill ID</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Total</th>
                  <th className="p-3">Date</th>
                </tr>
              </thead>
              <tbody>
                {bills.map((bill) => (
                  <tr key={bill.id} className="border-t" data-testid={`bill-row-${bill.id}`}>
                    <td className="p-3" data-testid={`bill-id-${bill.id}`}>{bill.id.slice(0, 8)}</td>
                    <td className="p-3" data-testid={`bill-status-${bill.id}`}>{bill.status}</td>
                    <td className="p-3 text-right" data-testid={`bill-total-${bill.id}`}>{formatCurrency(bill.total_amount)}</td>
                    <td className="p-3" data-testid={`bill-date-${bill.id}`}>{formatDateTime(bill.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
