import { useState } from "react";
import { BrowserRouter } from "react-router-dom";
import "@/App.css";
import { AuthPage } from "@/components/AuthPage";
import { AppShell } from "@/components/AppShell";

const SESSION_KEY = "mybillbook-session";

const getStoredSession = () => {
  const rawSession = localStorage.getItem(SESSION_KEY);
  if (!rawSession) return null;
  try {
    return JSON.parse(rawSession);
  } catch {
    return null;
  }
};

function App() {
  const [session, setSession] = useState(getStoredSession());

  const handleAuthSuccess = (authPayload) => {
    const nextSession = {
      token: authPayload.token,
      user: authPayload.user,
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(nextSession));
    setSession(nextSession);
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    setSession(null);
  };

  if (!session) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <BrowserRouter>
      <AppShell session={session} onLogout={handleLogout} />
    </BrowserRouter>
  );
}

export default App;
