import { useEffect, useState } from "react";
import { Link, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { LayoutDashboard, Users, Package, ShoppingCart, Receipt, CreditCard, Shield, Ticket, LogOut, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { DashboardPage } from "@/pages/DashboardPage";
import { PartiesPage } from "@/pages/PartiesPage";
import { InventoryPage } from "@/pages/InventoryPage";
import { PurchaseOrdersPage } from "@/pages/PurchaseOrdersPage";
import { BillsPage } from "@/pages/BillsPage";
import { SubscriptionPage } from "@/pages/SubscriptionPage";
import { UsersPage } from "@/pages/UsersPage";
import { AdminDashboardPage } from "@/pages/AdminDashboardPage";
import { PromoCodesPage } from "@/pages/PromoCodesPage";

const ownerMenu = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, testid: "nav-dashboard-link" },
  { to: "/parties", label: "Parties", icon: Users, testid: "nav-parties-link" },
  { to: "/inventory", label: "Inventory", icon: Package, testid: "nav-inventory-link" },
  { to: "/purchase-orders", label: "Purchase Orders", icon: ShoppingCart, testid: "nav-purchase-orders-link" },
  { to: "/bills", label: "Bill Entry", icon: Receipt, testid: "nav-bills-link" },
  { to: "/subscription", label: "Subscription", icon: CreditCard, testid: "nav-subscription-link" },
];

const ownerOnlyMenu = [{ to: "/users", label: "Staff Users", icon: Users, testid: "nav-users-link" }];

const adminMenu = [
  { to: "/admin", label: "Super Admin", icon: Shield, testid: "nav-admin-link" },
  { to: "/promo-codes", label: "Promo Codes", icon: Ticket, testid: "nav-promo-link" },
];

const SidebarItem = ({ item, pathname }) => {
  const Icon = item.icon;
  const isActive = pathname === item.to;

  return (
    <Link
      to={item.to}
      data-testid={item.testid}
      className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
        isActive ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
      }`}
    >
      <Icon size={18} />
      <span>{item.label}</span>
    </Link>
  );
};

export const AppShell = ({ session, onLogout }) => {
  const location = useLocation();
  const isSuperAdmin = session.user.role === "super_admin";
  const isOwner = session.user.role === "owner";
  const visibleMenu = isSuperAdmin ? adminMenu : [...ownerMenu, ...(isOwner ? ownerOnlyMenu : [])];
  const [subscriptionGate, setSubscriptionGate] = useState({
    has_active_subscription: isSuperAdmin,
    subscription: null,
    message: "",
  });

  const fetchSubscriptionGate = async () => {
    if (isSuperAdmin) {
      setSubscriptionGate({ has_active_subscription: true, subscription: null, message: "" });
      return;
    }

    try {
      const response = await api.get("/subscriptions/access-status");
      setSubscriptionGate(response.data || { has_active_subscription: false, subscription: null, message: "" });
    } catch {
      setSubscriptionGate({ has_active_subscription: false, subscription: null, message: "Unable to load subscription status" });
    }
  };

  useEffect(() => {
    fetchSubscriptionGate();
  }, [isSuperAdmin, session.user.id]);

  return (
    <div className="min-h-screen bg-slate-50" data-testid="app-shell">
      <div className="mx-auto grid min-h-screen max-w-[1600px] grid-cols-1 md:grid-cols-[260px_1fr]">
        <aside className="border-r border-slate-200 bg-white p-5" data-testid="sidebar-panel">
          <div className="mb-8">
            <h1 className="display-font text-2xl font-bold text-slate-900" data-testid="app-logo-title">
              MyBillBook
            </h1>
            <p className="text-xs text-slate-500" data-testid="app-logo-subtitle">
              India GST Billing Platform
            </p>
            {!isSuperAdmin && !subscriptionGate.has_active_subscription ? (
              <div className="mt-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700" data-testid="sidebar-subscription-warning">
                Subscription inactive
              </div>
            ) : null}
          </div>

          <nav className="space-y-1" data-testid="sidebar-navigation">
            {visibleMenu.map((item) => (
              <div key={item.to} className="relative">
                <SidebarItem item={item} pathname={location.pathname} />
                {!isSuperAdmin && item.to === "/subscription" ? (
                  <span
                    className={`absolute right-2 top-2 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                      subscriptionGate.has_active_subscription
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-amber-100 text-amber-700"
                    }`}
                    data-testid="subscription-nav-status-badge"
                  >
                    {subscriptionGate.has_active_subscription ? "ACTIVE" : "REQUIRED"}
                  </span>
                ) : null}
              </div>
            ))}
          </nav>

          <div className="mt-8 rounded-md border border-slate-200 bg-slate-50 p-3" data-testid="active-user-card">
            <p className="text-sm font-semibold text-slate-800" data-testid="active-user-name">
              {session.user.full_name}
            </p>
            <p className="text-xs text-slate-500" data-testid="active-user-role">
              Role: {session.user.role}
            </p>
            <Button
              variant="outline"
              className="mt-3 w-full"
              onClick={onLogout}
              data-testid="logout-button"
            >
              <LogOut size={16} className="mr-2" />
              Logout
            </Button>
          </div>
        </aside>

        <main className="p-4 md:p-6 lg:p-8" data-testid="main-content-area">
          <header className="mb-6 rounded-xl border border-slate-200 bg-white p-4" data-testid="top-header-bar">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="display-font text-xl font-semibold text-slate-900" data-testid="header-welcome-title">
                  Welcome, {session.user.full_name}
                </h2>
                <p className="text-sm text-slate-600" data-testid="header-welcome-business">
                  {session.user.business_name || "Developer Super Admin Console"}
                </p>
              </div>
              {!isSuperAdmin ? (
                <div className="rounded-full bg-blue-50 px-4 py-2 text-xs font-semibold text-blue-700" data-testid="header-subscription-chip">
                  {subscriptionGate.has_active_subscription
                    ? `Plan: ${subscriptionGate.subscription?.plan_name || "Active"}`
                    : "Read-only until payment confirmation"}
                </div>
              ) : null}
            </div>
          </header>

          {!isSuperAdmin && !subscriptionGate.has_active_subscription ? (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-4" data-testid="subscription-activation-banner">
              <div>
                <p className="display-font flex items-center gap-2 text-lg font-bold text-amber-800" data-testid="subscription-banner-title">
                  <Sparkles size={16} />
                  Activate subscription to unlock add/edit actions
                </p>
                <p className="text-sm text-amber-700" data-testid="subscription-banner-message">
                  You can view all data now. Create/update is enabled immediately after successful mock payment.
                </p>
              </div>
              <Link
                to="/subscription"
                className="rounded-md bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-700"
                data-testid="subscription-banner-activate-link"
              >
                Activate Now
              </Link>
            </div>
          ) : null}

          <Routes>
            {!isSuperAdmin ? (
              <>
                <Route path="/dashboard" element={<DashboardPage subscriptionGate={subscriptionGate} />} />
                <Route path="/parties" element={<PartiesPage hasActiveSubscription={subscriptionGate.has_active_subscription} />} />
                <Route path="/inventory" element={<InventoryPage hasActiveSubscription={subscriptionGate.has_active_subscription} />} />
                <Route path="/purchase-orders" element={<PurchaseOrdersPage hasActiveSubscription={subscriptionGate.has_active_subscription} />} />
                <Route path="/bills" element={<BillsPage hasActiveSubscription={subscriptionGate.has_active_subscription} />} />
                <Route
                  path="/subscription"
                  element={
                    <SubscriptionPage
                      session={session}
                      subscriptionGate={subscriptionGate}
                      onSubscriptionActivated={fetchSubscriptionGate}
                    />
                  }
                />
                {isOwner ? <Route path="/users" element={<UsersPage hasActiveSubscription={subscriptionGate.has_active_subscription} />} /> : null}
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </>
            ) : (
              <>
                <Route path="/admin" element={<AdminDashboardPage />} />
                <Route path="/promo-codes" element={<PromoCodesPage />} />
                <Route path="*" element={<Navigate to="/admin" replace />} />
              </>
            )}
          </Routes>
        </main>
      </div>
    </div>
  );
};
