import { useState } from "react";
import { publicApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const AuthPage = ({ onAuthSuccess }) => {
  const [activeTab, setActiveTab] = useState("login");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({
    full_name: "",
    email: "",
    password: "",
    business_name: "",
    gstin: "",
  });

  const handleLogin = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await publicApi.post("/auth/login", loginForm);
      onAuthSuccess(response.data);
    } catch (requestError) {
      setError(requestError?.response?.data?.detail || "Unable to login");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await publicApi.post("/auth/register-owner", registerForm);
      onAuthSuccess(response.data);
    } catch (requestError) {
      setError(requestError?.response?.data?.detail || "Unable to register");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen w-full lg:grid-cols-2">
      <div className="fade-in-up grid-pattern flex items-center justify-center px-4 py-8 md:px-10">
        <Card className="w-full max-w-lg border-slate-200 shadow-xl" data-testid="auth-card">
          <CardHeader className="space-y-3">
            <CardTitle className="display-font text-4xl text-slate-900" data-testid="auth-heading">
              MyBillBook Pro
            </CardTitle>
            <p className="text-sm text-slate-600" data-testid="auth-subtitle">
              GST billing, inventory, parties, purchase orders, subscriptions and super-admin controls.
            </p>
            <div className="rounded-md bg-slate-50 p-3 text-xs text-slate-600" data-testid="super-admin-demo-credentials">
              Super Admin Demo: admin@mybillbook.dev / admin123
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-5 flex rounded-md border border-slate-200 bg-slate-100 p-1">
              <button
                type="button"
                data-testid="login-tab-button"
                className={`w-1/2 rounded-md px-3 py-2 text-sm transition-colors ${
                  activeTab === "login" ? "bg-white text-slate-900 shadow" : "text-slate-600"
                }`}
                onClick={() => setActiveTab("login")}
              >
                Login
              </button>
              <button
                type="button"
                data-testid="register-tab-button"
                className={`w-1/2 rounded-md px-3 py-2 text-sm transition-colors ${
                  activeTab === "register" ? "bg-white text-slate-900 shadow" : "text-slate-600"
                }`}
                onClick={() => setActiveTab("register")}
              >
                Register Business
              </button>
            </div>

            {error ? (
              <div className="mb-4 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-600" data-testid="auth-error-message">
                {error}
              </div>
            ) : null}

            {activeTab === "login" ? (
              <form className="space-y-4" onSubmit={handleLogin} data-testid="login-form">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    required
                    value={loginForm.email}
                    data-testid="login-email-input"
                    onChange={(event) => setLoginForm((prev) => ({ ...prev, email: event.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    required
                    value={loginForm.password}
                    data-testid="login-password-input"
                    onChange={(event) => setLoginForm((prev) => ({ ...prev, password: event.target.value }))}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading} data-testid="login-submit-button">
                  {loading ? "Please wait..." : "Login"}
                </Button>
              </form>
            ) : (
              <form className="space-y-4" onSubmit={handleRegister} data-testid="register-form">
                <div className="space-y-2">
                  <Label htmlFor="register-name">Owner Name</Label>
                  <Input
                    id="register-name"
                    required
                    value={registerForm.full_name}
                    data-testid="register-owner-name-input"
                    onChange={(event) => setRegisterForm((prev) => ({ ...prev, full_name: event.target.value }))}
                  />
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email</Label>
                    <Input
                      id="register-email"
                      type="email"
                      required
                      value={registerForm.email}
                      data-testid="register-email-input"
                      onChange={(event) => setRegisterForm((prev) => ({ ...prev, email: event.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Password</Label>
                    <Input
                      id="register-password"
                      type="password"
                      required
                      value={registerForm.password}
                      data-testid="register-password-input"
                      onChange={(event) => setRegisterForm((prev) => ({ ...prev, password: event.target.value }))}
                    />
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="register-business">Business Name</Label>
                    <Input
                      id="register-business"
                      required
                      value={registerForm.business_name}
                      data-testid="register-business-name-input"
                      onChange={(event) => setRegisterForm((prev) => ({ ...prev, business_name: event.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-gstin">GSTIN</Label>
                    <Input
                      id="register-gstin"
                      value={registerForm.gstin}
                      data-testid="register-gstin-input"
                      onChange={(event) => setRegisterForm((prev) => ({ ...prev, gstin: event.target.value }))}
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={loading} data-testid="register-submit-button">
                  {loading ? "Please wait..." : "Create Business Account"}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="relative hidden lg:block">
        <img
          src="https://images.pexels.com/photos/16498505/pexels-photo-16498505.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=1200&w=1200"
          alt="Billing and business management"
          className="h-full w-full object-cover"
          data-testid="auth-hero-image"
        />
        <div className="absolute inset-0 bg-slate-900/45" />
        <div className="absolute bottom-10 left-10 max-w-md text-white">
          <h2 className="display-font text-4xl font-bold" data-testid="hero-title">
            Run your billing business from one place
          </h2>
          <p className="mt-3 text-sm text-white/90" data-testid="hero-subtitle">
            Invoice fast, track inventory, manage purchase orders, apply promo codes and monitor monthly/yearly sales.
          </p>
        </div>
      </div>
    </div>
  );
};
