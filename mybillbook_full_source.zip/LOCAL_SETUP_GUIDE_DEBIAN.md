# MyBillBook Clone — Debian Local Setup + Hosting Guide

## 1) What this build uses
- **Frontend:** React (CRA + Tailwind)
- **Backend:** FastAPI
- **Database:** **MongoDB**
- **Subscription payment flow:** **MOCKED gateway** (for demo/testing)

---

## 2) Debian prerequisites

```bash
sudo apt update
sudo apt install -y curl git unzip python3 python3-pip python3-venv build-essential
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g yarn
```

Check versions:

```bash
node -v
yarn -v
python3 --version
```

---

## 3) Install MongoDB on Debian

```bash
sudo apt install -y gnupg
curl -fsSL https://pgp.mongodb.com/server-7.0.asc | \
  sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor
echo "deb [ signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/debian bookworm/mongodb-org/7.0 main" | \
  sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update
sudo apt install -y mongodb-org
sudo systemctl enable mongod
sudo systemctl start mongod
sudo systemctl status mongod
```

---

## 4) Project setup

```bash
git clone <your-repo-url>
cd <your-project-folder>
```

### Backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Create/update `backend/.env`:

```env
MONGO_URL="mongodb://localhost:27017"
DB_NAME="mybillbook_db"
CORS_ORIGINS="http://localhost:3000"
JWT_SECRET="change_this_to_a_strong_secret"
```

Run backend:

```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend

```bash
cd ../frontend
yarn install
```

Create/update `frontend/.env`:

```env
REACT_APP_BACKEND_URL=http://localhost:8001
WDS_SOCKET_PORT=3000
ENABLE_HEALTH_CHECK=false
```

Run frontend:

```bash
yarn start
```

Open: `http://localhost:3000`

---

## 5) Local login notes

- **Super Admin (seeded):** `admin@mybillbook.dev` / `admin123`
- Owner can register from the Register tab.
- Without subscription payment confirmation, business modules stay **read-only**.

---

## 6) Hosting guide (AWS / Cloudflare)

### Option A: AWS (recommended for full stack + MongoDB)

1. **Frontend:** deploy to S3 + CloudFront (or Amplify).
2. **Backend:** deploy FastAPI on EC2 / ECS / App Runner.
3. **Database:** use MongoDB Atlas (recommended) or self-managed MongoDB.
4. Set backend env:
   - `MONGO_URL` (Atlas connection string)
   - `DB_NAME`
   - `JWT_SECRET`
   - `CORS_ORIGINS` (your frontend domain)
5. Set frontend env:
   - `REACT_APP_BACKEND_URL=https://api.yourdomain.com`
6. Add reverse proxy (Nginx/Caddy) + SSL (Let’s Encrypt or ACM).

### Option B: Cloudflare setup

Cloudflare is best used for **DNS + CDN + SSL + WAF** in this architecture.

1. Host frontend (S3/Vercel/Netlify/EC2) and backend (EC2/ECS/App Runner).
2. Point DNS in Cloudflare:
   - `app.yourdomain.com` → frontend
   - `api.yourdomain.com` → backend
3. Enable TLS Full (strict), caching rules for static assets, and WAF rules.

> Note: Cloudflare alone is not your app runtime for this full FastAPI + MongoDB stack unless you redesign to Workers-compatible architecture.

---

## 7) Production checklist

- Change `JWT_SECRET` to strong value.
- Restrict CORS to exact frontend domain.
- Use managed MongoDB backups.
- Add monitoring/logging (CloudWatch + alerts).
- Keep mock payment for demo only; replace with real gateway for production billing.
